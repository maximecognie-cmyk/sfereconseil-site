(function () {
  // Parcours animé de la facture (page d'accueil)
  var steps = document.getElementById('steps');
  if (steps) {
    var setH = function () {
      var li = steps.querySelectorAll('li');
      if (li.length) steps.style.setProperty('--h', (li[li.length - 1].offsetTop - li[0].offsetTop) + 'px');
    };
    setH(); addEventListener('resize', setH); addEventListener('load', setH);
  }

  // Menu mobile
  var tog = document.querySelector('.menu-toggle'), mob = document.getElementById('mobile-nav');
  if (tog && mob) tog.addEventListener('click', function () {
    var open = mob.hidden; mob.hidden = !open; tog.setAttribute('aria-expanded', String(open));
  });

  // Boutons « Copier »
  function sel(el) { var r = document.createRange(); r.selectNodeContents(el); var s = getSelection(); s.removeAllRanges(); s.addRange(r); }
  document.querySelectorAll('[data-copy]').forEach(function (b) {
    b.addEventListener('click', function () {
      var el = document.getElementById(b.dataset.copy);
      var ok = function () { b.textContent = 'Copié'; setTimeout(function () { b.textContent = 'Copier'; }, 1600); };
      try { navigator.clipboard.writeText(el.textContent.trim()).then(ok, function () { sel(el); }); } catch (e) { sel(el); }
    });
  });

  // Formulaire de contact en 3 étapes (envoi via Formspree)
  var f = document.getElementById('qform');
  if (!f) return;
  var sets = [].slice.call(f.querySelectorAll('[data-step]')), bars = [].slice.call(f.querySelectorAll('.progress i'));
  var next = document.getElementById('next'), prev = document.getElementById('prev'), err = document.getElementById('err');
  var i = 0;
  function show() {
    sets.forEach(function (s, k) { s.hidden = k !== i; });
    bars.forEach(function (b, k) { b.classList.toggle('on', k <= i); });
    prev.hidden = i === 0;
    next.firstChild.textContent = i === sets.length - 1 ? 'Envoyer ma demande ' : 'Continuer ';
    err.textContent = '';
  }
  function valid() {
    if (i === 0 && !f.querySelector('input[name=structure]:checked')) return 'Choisissez le type de structure.';
    if (i === 1 && !f.querySelector('input[name=sujet]:checked')) return 'Cochez au moins un sujet.';
    if (i === 2) {
      if (!f.querySelector('#f-nom').value.trim()) return 'Indiquez votre nom.';
      if (!/^\S+@\S+\.\S+$/.test(f.querySelector('#f-mail').value.trim())) return 'Vérifiez votre adresse e-mail.';
    }
    return '';
  }
  function done() {
    sets.forEach(function (s) { s.hidden = true; });
    document.getElementById('navq').hidden = true;
    document.getElementById('done').hidden = false;
    bars.forEach(function (b) { b.classList.add('on'); });
    err.textContent = '';
  }
  function send() {
    var action = f.getAttribute('action') || '';
    if (action.indexOf('VOTRE_ID') !== -1) { done(); return; } // maquette : pas encore relié
    var data = new FormData(f);
    data.set('sujet', [].slice.call(f.querySelectorAll('input[name=sujet]:checked')).map(function (c) { return c.value; }).join(', '));
    f.classList.add('sending');
    fetch(action, { method: 'POST', body: data, headers: { 'Accept': 'application/json' } })
      .then(function (r) { if (!r.ok) throw new Error(); done(); })
      .catch(function () { err.textContent = "L'envoi n'a pas abouti. Écrivez-nous à contact@sfereconseil.com ou appelez le 07 63 17 82 99."; })
      .finally(function () { f.classList.remove('sending'); });
  }
  next.addEventListener('click', function () {
    var e = valid(); if (e) { err.textContent = e; return; }
    if (i < sets.length - 1) { i++; show(); } else { send(); }
  });
  prev.addEventListener('click', function () { if (i > 0) { i--; show(); } });
  f.addEventListener('submit', function (e) { e.preventDefault(); next.click(); });
})();
