(function () {
  var reduce = window.matchMedia && matchMedia('(prefers-reduced-motion: reduce)').matches;
  document.documentElement.classList.add('js');

  // Apparition au défilement
  var els = [].slice.call(document.querySelectorAll('[data-reveal]'));
  if ('IntersectionObserver' in window && !reduce) {
    var io = new IntersectionObserver(function (entries) {
      entries.forEach(function (e) { if (e.isIntersecting) { e.target.classList.add('in'); io.unobserve(e.target); } });
    }, { rootMargin: '0px 0px 12% 0px' });
    els.forEach(function (el, k) { el.style.transitionDelay = ((k % 3) * 40) + 'ms'; io.observe(el); });
  } else { els.forEach(function (el) { el.classList.add('in'); }); }

  // Compteurs
  var counters = [].slice.call(document.querySelectorAll('[data-count]'));
  function runCount(el) {
    var end = +el.dataset.count, t0 = null, d = 1400;
    if (reduce) { el.textContent = end; return; }
    function step(t) { if (!t0) t0 = t; var p = Math.min((t - t0) / d, 1); el.textContent = Math.round(end * (1 - Math.pow(1 - p, 3))); if (p < 1) requestAnimationFrame(step); }
    requestAnimationFrame(step);
  }
  if ('IntersectionObserver' in window) {
    var co = new IntersectionObserver(function (en) { en.forEach(function (e) { if (e.isIntersecting) { runCount(e.target); co.unobserve(e.target); } }); }, { threshold: .6 });
    counters.forEach(function (c) { co.observe(c); });
  }

  // Carte « parcours » tournante
  var flow = document.getElementById('flow');
  if (flow) {
    var tabs = [].slice.call(flow.querySelectorAll('[role=tab]')), panels = [].slice.call(flow.querySelectorAll('[role=tabpanel]'));
    var bar = flow.querySelector('.flow-progress i'), cur = 0, timer = null, stepTimer = null, paused = false, DUR = 8000;
    flow.style.setProperty('--dur', DUR + 'ms');
    function lightSteps(panel) {
      clearInterval(stepTimer);
      var lis = [].slice.call(panel.querySelectorAll('.steps li')), i = 0;
      lis.forEach(function (l) { l.classList.remove('on'); });
      if (!lis.length) return;
      lis[0].classList.add('on');
      stepTimer = setInterval(function () { i++; if (i < lis.length) lis[i].classList.add('on'); else clearInterval(stepTimer); }, (DUR - 600) / lis.length);
    }
    function show(n, user) {
      cur = (n + tabs.length) % tabs.length;
      tabs.forEach(function (t, k) { t.setAttribute('aria-selected', k === cur); t.tabIndex = k === cur ? 0 : -1; });
      panels.forEach(function (p, k) { p.hidden = k !== cur; });
      flow.style.setProperty('--c', tabs[cur].dataset.c);
      if (reduce) { panels[cur].querySelectorAll('.steps li').forEach(function (l) { l.classList.add('on'); }); return; }
      lightSteps(panels[cur]);
      bar.classList.remove('run'); void bar.offsetWidth; if (!paused) bar.classList.add('run');
      clearTimeout(timer); if (!paused) timer = setTimeout(function () { show(cur + 1); }, DUR);
      if (user) tabs[cur].scrollIntoView({ block: 'nearest', inline: 'nearest' });
    }
    tabs.forEach(function (t, k) {
      t.addEventListener('click', function () { show(k, true); });
      t.addEventListener('keydown', function (e) {
        if (e.key === 'ArrowRight') { show(cur + 1, true); tabs[cur].focus(); }
        if (e.key === 'ArrowLeft') { show(cur - 1, true); tabs[cur].focus(); }
      });
    });
    function pause(v) { paused = v; if (v) { clearTimeout(timer); bar.style.animationPlayState = 'paused'; } else { bar.style.animationPlayState = 'running'; show(cur); } }
    flow.addEventListener('mouseenter', function () { pause(true); });
    flow.addEventListener('mouseleave', function () { pause(false); });
    flow.addEventListener('focusin', function () { pause(true); });
    flow.addEventListener('focusout', function () { pause(false); });
    show(0);
  }

  // Menu mobile
  var tog = document.querySelector('.menu-toggle'), mob = document.getElementById('mobile-nav');
  if (tog && mob) tog.addEventListener('click', function () { var open = mob.hidden; mob.hidden = !open; tog.setAttribute('aria-expanded', String(open)); });

  // Copier
  function sel(el) { var r = document.createRange(); r.selectNodeContents(el); var s = getSelection(); s.removeAllRanges(); s.addRange(r); }
  document.querySelectorAll('[data-copy]').forEach(function (b) {
    b.addEventListener('click', function () {
      var el = document.getElementById(b.dataset.copy);
      var ok = function () { b.textContent = 'Copié'; setTimeout(function () { b.textContent = 'Copier'; }, 1600); };
      try { navigator.clipboard.writeText(el.textContent.trim()).then(ok, function () { sel(el); }); } catch (e) { sel(el); }
    });
  });

  // Filtres de la page Actualités
  var fl = document.querySelector('[data-filters]');
  if (fl) {
    var fb = [].slice.call(fl.querySelectorAll('button')), fp = [].slice.call(document.querySelectorAll('.post[data-cat]')), fe = document.getElementById('filter-empty');
    fb.forEach(function (b) {
      b.addEventListener('click', function () {
        var c = b.dataset.f, n = 0;
        fb.forEach(function (x) { x.setAttribute('aria-pressed', String(x === b)); });
        fp.forEach(function (p) { var on = c === 'all' || p.dataset.cat === c; p.hidden = !on; if (on) { n++; p.classList.add('in'); } });
        if (fe) fe.hidden = n > 0;
      });
    });
  }

  // Formulaire de contact en 3 étapes (Formspree)
  var f = document.getElementById('qform');
  if (!f) return;
  var sets = [].slice.call(f.querySelectorAll('[data-step]')), bars = [].slice.call(f.querySelectorAll('.progress i'));
  var next = document.getElementById('next'), prev = document.getElementById('prev'), err = document.getElementById('err'), i = 0;
  function showStep() {
    sets.forEach(function (s, k) { s.hidden = k !== i; });
    bars.forEach(function (b, k) { b.classList.toggle('on', k <= i); });
    prev.hidden = i === 0;
    next.firstChild.textContent = i === sets.length - 1 ? 'Envoyer ma demande ' : 'Continuer ';
    err.textContent = '';
  }
  function valid() {
    if (i === 0 && !f.querySelector('input[name=structure]:checked')) return 'Choisissez le type de structure.';
    if (i === 1 && !f.querySelector('input[name=sujet]:checked')) return 'Cochez au moins un sujet.';
    if (i === 2) {
      if (!f.querySelector('#f-nom').value.trim()) return 'Indiquez votre nom.';
      if (!/^\S+@\S+\.\S+$/.test(f.querySelector('#f-mail').value.trim())) return 'Vérifiez votre adresse e-mail.';
    }
    return '';
  }
  function done() {
    sets.forEach(function (s) { s.hidden = true; });
    document.getElementById('navq').hidden = true;
    document.getElementById('done').hidden = false;
    bars.forEach(function (b) { b.classList.add('on'); });
    err.textContent = '';
  }
  function send() {
    var action = f.getAttribute('action') || '';
    if (action.indexOf('VOTRE_ID') !== -1) { done(); return; }
    var data = new FormData(f);
    data.set('sujet', [].slice.call(f.querySelectorAll('input[name=sujet]:checked')).map(function (c) { return c.value; }).join(', '));
    f.classList.add('sending');
    fetch(action, { method: 'POST', body: data, headers: { 'Accept': 'application/json' } })
      .then(function (r) { if (!r.ok) throw new Error(); done(); })
      .catch(function () { err.textContent = "L'envoi n'a pas abouti. Écrivez-nous à contact@sfereconseil.com ou appelez le 07 63 17 82 99."; })
      .finally(function () { f.classList.remove('sending'); });
  }
  next.addEventListener('click', function () { var e = valid(); if (e) { err.textContent = e; return; } if (i < sets.length - 1) { i++; showStep(); } else { send(); } });
  prev.addEventListener('click', function () { if (i > 0) { i--; showStep(); } });
  f.addEventListener('submit', function (e) { e.preventDefault(); next.click(); });
})();
